#ifndef __DEVICE_INFO_SERVICE_H
#define __DEVICE_INFO_SERVICE_H

// Functions
void simple_ble_device_info_service_automatic();
void simple_ble_device_info_service(char* hw_rev, char* fw_rev, char* sw_rev);

#endif //__DEVICE_INFO_SERVICE_H


#include "smtc_hal_watchdog.h"

void hal_watchdog_init( void )
{
	
}

void hal_watchdog_reload( void )
{
	
}
